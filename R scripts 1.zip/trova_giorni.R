for (i in 2:957109) 
  if (X20210924_anon_odonto[i,4]==X20210924_anon_odonto[i-1,4])
    X20210924_anon_odonto[i,11]=X20210924_anon_odonto[i,6]-X20210924_anon_odonto[i-1,6]



for (i in 2:14341){
  if (X[i,4]==X[i-1,4])
  {i-1=j & X[i,11]=X[i,6]-X[i-1,6]}
  else {X[i,11]=0}}
  

min <- summarise(group_by(X, paziente), minimo = min(data_danno))


for (i in 1:14341){
  for (j in 1:4497 ){
    if (X[i,4]==min[j,1])
      X[i,12]=min[j,2]
  }
}
  
  
