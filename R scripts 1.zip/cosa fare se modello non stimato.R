library(readxl)
x <- read_excel("riassunto/x.xlsx")

statetable.msm(prestazione, paziente, data=x)

Q1= matrix(rep(1, time=361), nrow = 19)
diag(Q1) <- 0
Q1.crude <- crudeinits.msm(prestazione ~ data_danno, paziente, data=x,
                          qmatrix=Q1)

#ora suppongo di non poter stimare il modello a causa del problema di memoria

Q1.crude # mi fornisce ci� che mi viene fornito come stima dalla stima del modello quando viene richiamato, anche se in questo caso siamo sprovvisti di intervalli di confidenza

tab1 <-statetable.msm(prestazione, paziente, data=x)
tab1 <- matrix(as.numeric(tab1), nrow = nrow(tab1), ncol = ncol(tab1))

  
for (i in 1:19) {
  a[i] <-sum(tab1[i,])
}

for(i in 1:19)
  for(j in 1:19)
    tab1[i,j]=tab1[i,j]/a[i]
#in questo modo trovo le probabilit� di passaggio da uno stato all'altro, indipendenti per� dal tempo

P1 <- pmatrix.msm(prova1.msm, t=20) 

library(Matrix)
P_1 <- expm(20*Q1.crude)

