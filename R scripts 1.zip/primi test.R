library(msm)

#1
x <- read_excel("x.xlsx")

statetable.msm(prestazione, paziente, data=x)

Q= matrix(rep(1, time=361), nrow = 19)
diag(Q) <- 0
Q.crude <- crudeinits.msm(prestazione ~ data_danno, paziente, data=x,
                                           qmatrix=Q)

t0=Sys.time()
prova.msm <- msm( prestazione ~ data_danno, subject=paziente, data = x, qmatrix = Q.crude, obstype = c(rep(2, time=131)))
Sys.time()-t0

P <- pnext.msm(prova.msm) #qui le probabilit� in diagonale sono zero poich� calcolo -q_rs/q_rr
                          #probabilit� che lo stato s sia il prossimo
P1 <- pmatrix.msm(prova.msm, t=20) 
P11 <- pmatrix.msm(prova.msm, t=40)

sojourn.msm(prova.msm) #tempo medio permanenza in uno stato

#2
X20211004_anon_odonto <- read_excel("//lucchettam/scambio/Overtreatment/Dataset/20211004_anon_odonto.xlsx")

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="1� VISITA ORALE + 1�ABLAZIONE TARTARO ANNUALE (1) (3)")
    X20211004_anon_odonto[i, 19]=1

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CAVIT� DI 1� CLASSE DI BLACK")
    X20211004_anon_odonto[i, 19]=2

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CAVIT� DI 5� CLASSE DI BLACK")
    X20211004_anon_odonto[i, 19]=3

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CAVIT� DI 2� CLASSE DI BLACK")
    X20211004_anon_odonto[i, 19]=4

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CAVIT� DI 4� CLASSE")
    X20211004_anon_odonto[i, 19]=5

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="LEVIGATURA DELLE RADICI E/O COURETTAGE GENGIVALE (PER 6 DENTI)")
    X20211004_anon_odonto[i, 19]=6

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RADIOGRAFIA ENDORALE (OGNI DUE ELEMENTI)")
    X20211004_anon_odonto[i, 19]=7

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="INCAPPUCCIAMENTO")
    X20211004_anon_odonto[i, 19]=8

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CAVIT� DI 3� CLASSE")
    X20211004_anon_odonto[i,19]=9

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ORTOPANTOMOGRAFIA O ORTOPANORAMICA")
    X20211004_anon_odonto[i, 19]=10

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="TRATTAMENTO CHIMICO DELL'IPERSENSIBILIT� E PROFILASSI CARIE CON APPLICAZIONI TOPICHE OLIGOELEMENTI (PER ARCATA)")
    X20211004_anon_odonto[i, 19]=11

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RIMOZIONE DI CORONE O PERNI ENDOCANALARI (PER SINGOLO PILASTRO O PER SINGOLO PERNO). NON APPLICABILE AGLI ELEMENTI INTERMEDI DI PONTE")
    X20211004_anon_odonto[i, 19]=12
for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RITRATTAMENTO CANALARE (PRESTAZIONE A TRE CANALI) (COMPRESE RX E QUALUNQUE TIPO DI OTTURAZIONE)(1)")
    X20211004_anon_odonto[i, 19]=13

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RICOSTRUZIONE DEL DENTE CON ANCORAGGIO A VITE O A PERNO - AD ELEMENTO")
    X20211004_anon_odonto[i, 19]=14

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CORONA PROTESICA PROVVISORIA SEMPLICE IN RESINA")
    X20211004_anon_odonto[i, 19]=15

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="CERAMICA INTEGRALE")
    X20211004_anon_odonto[i, 19]=16

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RITRATTAMENTO CANALARE (PRESTAZIONE A DUE CANALI) (COMPRESE RX E QUALUNQUE TIPO DI OTTURAZIONE)(1)")
    X20211004_anon_odonto[i,19]=17

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ENDODONZIA (PRESTAZIONE A TRE CANALI) (COMPRESE RX E QUALUNQUE TIPO DI OTTURAZIONE NECESSARIA)")
    X20211004_anon_odonto[i, 19]=18

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ESTRAZIONE DI DENTE O RADICE")
    X20211004_anon_odonto[i, 19]=19

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ESTRAZIONE COMPLICATA DI DENTE O RADICE (COMPRESO EVENTUALE RASCHIAMENTO CAVIT� ALVEOLARE, SUTURA, RIMOZIONE PUNTI E MEDICAZIONI PER CONTROLLO SANGUINAMENTO TIPO COLLAGENE, FIBRINA, ECC...)")
    X20211004_anon_odonto[i, 19]=20

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="IMPIANTO OSTEOINTEGRATO (RICOPERTI IN CERAMICA, CARBON-VITREOUS, IDROSSIAPATITE, TITANIO PURO) PER ELEMENTO - COME UNICA PRESTAZIONE*")
    X20211004_anon_odonto[i, 19]=21

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ABLAZIONE TARTARO")
    X20211004_anon_odonto[i, 19]=22

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="VISITA ORALE")
    X20211004_anon_odonto[i, 19]=23

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="ENDODONZIA (PRESTAZIONE AD UN CANALE) (COMPRESE RX E QUALUNQUE TIPO DI OTTURAZIONE NECESSARIA)")
    X20211004_anon_odonto[i, 19]=24

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="PLACCA DI SVINCOLO")
    X20211004_anon_odonto[i, 19]=25

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="BITE NOTTURNO")
    X20211004_anon_odonto[i, 19]=26

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="BITE WING")
    X20211004_anon_odonto[i, 19]=27

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="RADIOGRAFIA ENDORALE PER ARCATE")
    X20211004_anon_odonto[i, 19]=28

for(i in 1:228)
  if (X20211004_anon_odonto[i, 9]=="VISITA ORTODONTICA (PRIMA VISITA) INCLUSO RILIEVO PER IMPRONTE PER MODELLI DI STUDIO")
    X20211004_anon_odonto[i, 19]=29


statetable.msm(prestazione, paziente, data=X20211004_anon_odonto)

Q1= matrix(rep(1, time=841), nrow = 29)
diag(Q1) <- 0
Q.crude1 <- crudeinits.msm(prestazione ~ giorno, paziente, data=X20211004_anon_odonto,
                          qmatrix=Q1)

t0=Sys.time()
prova2.msm <- msm( prestazione ~ giorno, subject=paziente, data = X20211004_anon_odonto, qmatrix = Q.crude1, obstype = c(rep(2, time=228)))
Sys.time()-t0
#intervalli di confidenza grandi, troppe poche righe rispetto a prestazioni?

P2 <- pnext.msm(prova2.msm) 

P3 <- pmatrix.msm(prova2.msm, t=300)
