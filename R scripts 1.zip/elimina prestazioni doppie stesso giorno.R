#eliminazione righe doppie


df[!duplicated(df), ]




#concatenazione prestazioni stesso paziente, stesso giorno

concatenazione <- X20211006_anon_odonto%>%
                        select(paziente, giorni, prestazione_aggregata)%>%
                          group_by(paziente, giorni)%>%
                          mutate(concatenazione_prest=paste(prestazione_aggregata, collapse = "--"))
                        