mutate(a, prest=NA)



for(i in 1:749210){
  if (X20211012_anon_odonto_story_1300rows[i, 15]=="allungamento di corona clinica")
    X20211012_anon_odonto_story_1300rows[i, 16]=1 
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="arcata dentaria sup e inf")
    X20211012_anon_odonto_story_1300rows[i, 16]=2
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="atm")
    X20211012_anon_odonto_story_1300rows[i,16]=3
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="bite")
    X20211012_anon_odonto_story_1300rows[i, 16]=4
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="carie")
    X20211012_anon_odonto_story_1300rows[i, 16]=5
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia endo")
    X20211012_anon_odonto_story_1300rows[i, 16]=6
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia gengivale")
    X20211012_anon_odonto_story_1300rows[i, 16]=7
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia mucogengivale")
    X20211012_anon_odonto_story_1300rows[i, 16]=8
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia mucosa orale")
    X20211012_anon_odonto_story_1300rows[i,16]=9
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia orale")
    X20211012_anon_odonto_story_1300rows[i, 16]=10
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia orale infezioni")
    X20211012_anon_odonto_story_1300rows[i,16]= 11
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia parodontale")
    X20211012_anon_odonto_story_1300rows[i, 16]=12
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="chirurgia rigenerativa")
    X20211012_anon_odonto_story_1300rows[i, 16]=13
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="endo")
    X20211012_anon_odonto_story_1300rows[i, 16]=14
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="Endo_prestazione non pi� utilizzata")
    X20211012_anon_odonto_story_1300rows[i, 16]=15
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="estrazione")
    X20211012_anon_odonto_story_1300rows[i, 16]=16
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="igiene")
    X20211012_anon_odonto_story_1300rows[i,16]=17
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="impianto")
    X20211012_anon_odonto_story_1300rows[i, 16]=18
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="intarsio")
    X20211012_anon_odonto_story_1300rows[i, 16]=19
  else  if (X20211012_anon_odonto_story_1300rows[i, 15]=="modifica protesi")
    X20211012_anon_odonto_story_1300rows[i, 16]=20
  else if (X20211012_anon_odonto_story_1300rows[i,15]=="orto ordinaria")
    X20211012_anon_odonto_story_1300rows[i,16]= 21 
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="pedodonzia ordinaria")
    X20211012_anon_odonto_story_1300rows[i, 16]=22
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="visita")
    X20211012_anon_odonto_story_1300rows[i, 16]=23
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="perno")
    X20211012_anon_odonto_story_1300rows[i, 16]=24
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="profilassi")
    X20211012_anon_odonto_story_1300rows[i, 16]=25
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi fissa")
    X20211012_anon_odonto_story_1300rows[i, 16]=26
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi fissa/riparazione")
    X20211012_anon_odonto_story_1300rows[i, 16]=27
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi fissa definitiva")
    X20211012_anon_odonto_story_1300rows[i, 16]=28
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi fissa o endodonzia")
    X20211012_anon_odonto_story_1300rows[i, 16]=29
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi fissa provvisoria")
    X20211012_anon_odonto_story_1300rows[i, 16]=30
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi mobile")
    X20211012_anon_odonto_story_1300rows[i, 16]=31
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi mobile definitiva")
    X20211012_anon_odonto_story_1300rows[i, 16]=32
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="protesi mobile provvisoria")
    X20211012_anon_odonto_story_1300rows[i, 16]=33
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="ricostruzione di angoli")
    X20211012_anon_odonto_story_1300rows[i, 16]=34
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="rx")
    X20211012_anon_odonto_story_1300rows[i, 16]=35
  else  if (X20211012_anon_odonto_story_1300rows[i, 15]=="splint")
    X20211012_anon_odonto_story_1300rows[i, 16]=36
  else if (X20211012_anon_odonto_story_1300rows[i,15]=="orto invasiva")
    X20211012_anon_odonto_story_1300rows[i,16]= 37
  else if (X20211012_anon_odonto_story_1300rows[i, 15]=="pedodonzia invasiva")
    X20211012_anon_odonto_story_1300rows[i, 16]=38
}



#eliminare righe con paziente unico
for(i in 2:749209){
  if (prova_tempo[i,4]!=prova_tempo[i-1,4] & prova_tempo[i,4]!=prova_tempo[i+1,4])
    prova_tempo[i,17]="elimina"
}


prova_tempo <- filter(prova_tempo, singolo!="elimina")


prova_tempo <- as.data.frame(prova_tempo)
write.table(prova_tempo, file = "prova_tempo.csv", sep = ";")


mutate(prova_tempo, categoria="a")

for(i in 1:1287){
  if (X20211012_anon_odonto_story_1300rows[i, 5]=="allungamento di corona clinica")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="arcata dentaria sup e inf")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="atm")
    X20211012_anon_odonto_story_1300rows[i,6]="diagnostica"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="bite")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="carie")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia endo")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia gengivale")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia mucogengivale")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia mucosa orale")
    X20211012_anon_odonto_story_1300rows[i,6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia orale")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia orale infezioni")
    X20211012_anon_odonto_story_1300rows[i,6]= "invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia parodontale")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="chirurgia rigenerativa")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="endo")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="Endo_prestazione non pi� utilizzata")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="estrazione")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="igiene")
    X20211012_anon_odonto_story_1300rows[i,6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="impianto")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="intarsio")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else  if (X20211012_anon_odonto_story_1300rows[i, 5]=="modifica protesi")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i,5]=="orto ordinaria")
    X20211012_anon_odonto_story_1300rows[i,6]= "ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="pedodonzia odrinaria")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="visita")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="perno")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="profilassi")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi fissa")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi fissa/riparazione")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi fissa definitiva")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi fissa o endodonzia")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi fissa provvisoria")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi mobile")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi mobile definitiva")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="protesi mobile provvisoria")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="RICOSTRUZIONE DI ANGOLI")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="rx")
    X20211012_anon_odonto_story_1300rows[i, 6]="diagnostica"
  else  if (X20211012_anon_odonto_story_1300rows[i, 5]=="splint")
    X20211012_anon_odonto_story_1300rows[i, 6]="ordinaria"
  else if (X20211012_anon_odonto_story_1300rows[i,5]=="orto invasiva")
    X20211012_anon_odonto_story_1300rows[i,6]= "invasiva"
  else if (X20211012_anon_odonto_story_1300rows[i, 5]=="pedodonzia invasiva")
    X20211012_anon_odonto_story_1300rows[i, 6]="invasiva"
}






































