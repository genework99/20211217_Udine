


for(i in 1:4823){
  for (j in 1:212){
    if (X20211012_anon_odonto_story_4800rows[i, 2]==X20210921_mapping_aggregazioni_prestazioni_DENTISTA[j,1])
      X20210921_mapping_aggregazioni_prestazioni_DENTISTA[i,5]=X20210921_mapping_aggregazioni_prestazioni_DENTISTA[j,3]
  }
}