#test su 1595 righe, 50 pazienti, storia totale

library(readxl)
X20211012_anon_odonto_story_1300rows <- read_excel("20211012_anon_odonto_story_1300rows.xlsx")

library(msm)
tab <- statetable.msm(prest, paziente, data=X20211012_anon_odonto_story_1300rows)

Q= matrix(rep(1, time=1444), nrow = 38)
diag(Q) <- 0
Q.crude <- crudeinits.msm(prest ~ giorno, paziente, data=X20211012_anon_odonto_story_1300rows,
                          qmatrix=Q)

t0=Sys.time()
prova.msm <- msm( prest ~ giorno, subject=paziente, data = X20211012_anon_odonto_story_1300rows, qmatrix = Q.crude, obstype = c(rep(2, time=1279)))
Sys.time()-t0


P <- pnext.msm(prova.msm)

sojourn.msm(prova.msm)

P133 <- pmatrix.msm(prova.msm, t=133)


#
for(i in 1:4823){
  if (X20211012_anon_odonto_story_4800rows[i, 5]=="allungamento di corona clinica")
    X20211012_anon_odonto_story_4800rows[i, 4]=1 
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="arcata dentaria sup e inf")
    X20211012_anon_odonto_story_4800rows[i, 4]=2
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="atm")
    X20211012_anon_odonto_story_4800rows[i,4]=3
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="bite")
    X20211012_anon_odonto_story_4800rows[i, 4]=4
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="carie")
    X20211012_anon_odonto_story_4800rows[i, 4]=5
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia endo")
    X20211012_anon_odonto_story_4800rows[i, 4]=6
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia gengivale")
    X20211012_anon_odonto_story_4800rows[i, 4]=7
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia mucogengivale")
    X20211012_anon_odonto_story_4800rows[i, 4]=8
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia mucosa orale")
    X20211012_anon_odonto_story_4800rows[i,4]=9
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia orale")
    X20211012_anon_odonto_story_4800rows[i, 4]=10
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia orale infezioni")
    X20211012_anon_odonto_story_4800rows[i,4]= 11
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia parodontale")
    X20211012_anon_odonto_story_4800rows[i, 4]=12
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="chirurgia rigenerativa")
    X20211012_anon_odonto_story_4800rows[i, 4]=13
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="endo")
    X20211012_anon_odonto_story_4800rows[i, 4]=14
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="Endo_prestazione non pi� utilizzata")
    X20211012_anon_odonto_story_4800rows[i, 4]=15
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="estrazione")
    X20211012_anon_odonto_story_4800rows[i, 4]=16
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="igiene")
    X20211012_anon_odonto_story_4800rows[i,4]=17
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="impianto")
    X20211012_anon_odonto_story_4800rows[i, 4]=18
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="intarsio")
    X20211012_anon_odonto_story_4800rows[i, 4]=19
  else  if (X20211012_anon_odonto_story_4800rows[i, 5]=="modifica protesi")
    X20211012_anon_odonto_story_4800rows[i, 4]=20
  else if (X20211012_anon_odonto_story_4800rows[i,5]=="orto ordinaria")
    X20211012_anon_odonto_story_4800rows[i,4]= 21 
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="pedodonzia ordinaria")
    X20211012_anon_odonto_story_4800rows[i, 4]=22
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="visita")
    X20211012_anon_odonto_story_4800rows[i, 4]=23
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="perno")
    X20211012_anon_odonto_story_4800rows[i, 4]=24
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="profilassi")
    X20211012_anon_odonto_story_4800rows[i, 4]=25
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi fissa")
    X20211012_anon_odonto_story_4800rows[i, 4]=26
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi fissa/riparazione")
    X20211012_anon_odonto_story_4800rows[i, 4]=27
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi fissa definitiva")
    X20211012_anon_odonto_story_4800rows[i, 4]=28
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi fissa o endodonzia")
    X20211012_anon_odonto_story_4800rows[i, 4]=29
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi fissa provvisoria")
    X20211012_anon_odonto_story_4800rows[i, 4]=30
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi mobile")
    X20211012_anon_odonto_story_4800rows[i, 4]=31
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi mobile definitiva")
    X20211012_anon_odonto_story_4800rows[i, 4]=32
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="protesi mobile provvisoria")
    X20211012_anon_odonto_story_4800rows[i, 4]=33
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="ricostruzione di angoli")
    X20211012_anon_odonto_story_4800rows[i, 4]=34
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="rx")
    X20211012_anon_odonto_story_4800rows[i, 4]=35
  else  if (X20211012_anon_odonto_story_4800rows[i, 5]=="splint")
    X20211012_anon_odonto_story_4800rows[i, 4]=36
  else if (X20211012_anon_odonto_story_4800rows[i,5]=="orto invasiva")
    X20211012_anon_odonto_story_4800rows[i,4]= 37
  else if (X20211012_anon_odonto_story_4800rows[i, 5]=="pedodonzia invasiva")
    X20211012_anon_odonto_story_4800rows[i, 4]=38
}
