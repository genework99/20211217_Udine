library(readxl)
X20210924_anon_odonto <- read_excel("//lucchettam/Scambio/Overtreatment/Dataset/20210924_anon_odonto.xlsx")
library(tidyverse)


#per sapere il numero totale di ogni tipo di intervento
num_prest <- arrange(X20210924_anon_odonto%>%
                  count(den_prestazione), desc(n))

num_prestxpaz <- arrange(group_by(X20210924_anon_odonto, paziente)%>%
                   count(), desc(n))
tot_pazienti <- dim(num_prestxpaz)[1]


by_prest <- group_by(X20210924_anon_odonto, den_prestazione)
costo_medio_prest <- summarise(by_prest, costo_medio_prest = mean(imp_richiesto))
costo_medio_prest <- arrange(costo_medio_prest, desc(costo_medio_prest))

by_paziente <- group_by(X20210924_anon_odonto, paziente)
costo_tot_xpaziente <- summarise(by_paziente, costo_tot_xpaziente = sum(imp_richiesto) )
costo_tot_xpaziente<- arrange(costo_tot_xpaziente, desc(costo_tot_xpaziente))
costomedio_pazienti <- sum(costo_tot_xpaziente$costo_tot_xpaziente)/tot_pazienti

by_dentista <- group_by(X20210924_anon_odonto, dentista)
costotot_xdentista <- summarise(by_dentista, tot_xdentista = sum(imp_richiesto))
num_prestxdent <- group_by(X20210924_anon_odonto, dentista)%>%
                                  count()
num_dentisti_tot <- dim(num_prestxdent)[1]
media_prestxdent <- sum(num_prestxdent$n)/num_dentisti_tot
num_prestxdent[,3]=costotot_xdentista$tot_xdentista
num_prestxdent <- arrange(num_prestxdent, desc(n))

by_percipiente <- group_by(X20210924_anon_odonto, percipiente)
costotot_xpercipiente <- summarise(by_percipiente, costotot_xpercipiente = sum(imp_richiesto) )
costotot_xpercipiente <- arrange(costotot_xpercipiente, desc(costotot_xpercipiente))
num_prestxpercip <- arrange(group_by(X20210924_anon_odonto, percipiente)%>%
                             count(), desc(n))
num_percipienti_tot <- dim(num_prestxpercip)[1]
costomedio_percipienti <- sum(costotot_xpercipiente$costotot_xpercipiente)/num_percipienti_tot


costo_tot <- sum(X20210924_anon_odonto$imp_richiesto)
costo_tot_prestaz <- summarise(by_prest, costo_tot_prestaz = sum(imp_richiesto))
costo_tot_prestaz <- arrange(costo_tot_prestaz, desc(costo_tot_prestaz))

ggplot(data = num_prestxdent, mapping = aes(x=dentista, y=n))+
    geom_point()
ggplot(data = costotot_xdentista, mapping = aes(x=dentista, y=tot_xdentista))+
    geom_point()
ppp <- filter(X20210924_anon_odonto, dentista == "90e65fbd3ff9ef1942b562fa020ea64925769e92") #troppi soldi, troppe prestazioni
ggg <- filter(X20210924_anon_odonto, dentista == "2abceac5e022648ea8bb7591d21e8eaa6e7143d3") #troppi soldi, troppe prestazioni
mmm <- filter(X20210924_anon_odonto, dentista == "9dd677717b624264442f246ba29f83d40b11741c")
nnn <- filter(X20210924_anon_odonto, dentista == "0159711ee2983cf1b1ee58d08e1e2ebad05bc8dd")


fff1 <- filter(X20210924_anon_odonto, paziente == "2fa4d28ae824a3f5c03e4a215bebddd17777eb11") #tante prestazioni
fff2 <- filter(X20210924_anon_odonto, paziente == "746a0a5f22f1576ab7338b6ec177287373c7a567") #tante prestazioni, stesso dentista precedente
fff3 <- filter(X20210924_anon_odonto, paziente == "b53d1cc68491394726bd916cff0e947d624fda22") #stesso dentista
aaa <- filter(X20210924_anon_odonto, paziente == "1d6ed838a4c9157dab343726e1cecf40e60dae41")
bbb <- filter(X20210924_anon_odonto, paziente == "c1b8b8da6de6bda65833bfbe962e1f5bb062feac")
ccc <- filter(X20210924_anon_odonto, paziente == "7180f6fe2aa7502041c2ca0b0462e8aeb51ef728")

vvv <- filter(X20210924_anon_odonto, percipiente == "e493b33d3e6e6314148fef7606b2c95bb1ea263f") #percepiente di fff1, simili prestazioni
zzz <- filter(X20210924_anon_odonto, percipiente == "bc0c7cd46885df7ee8ee50e4486bc6de5d0e2996")
www <- filter(X20210924_anon_odonto, percipiente == "8d6d2e5ecd667683648f4036dc56d301a8a93308")


implant <- filter(X20210924_anon_odonto, den_prestazione == "MINI IMPLANT COMPRESI ATTACCHI DI PRECISIONE")
ggplot(data = implant, mapping = aes(x=paziente, y=imp_richiesto))+
   geom_point(mapping = aes(color = num_denti))
terapiaadulti <- filter(X20210924_anon_odonto, den_prestazione == "TERAPIA ORTODONTICA CON APPARECCHIATURE FISSE PER ARCATA PER ANNO - ADULTI")
ggplot(data = terapiaadulti, mapping = aes(x=paziente, y=imp_richiesto))+
      geom_point(mapping = aes(color = num_denti))
terapiaadolescenti <- filter(X20210924_anon_odonto, den_prestazione == "TERAPIA ORTODONTICA CON APPARECCHIATURE FISSE PER ARCATA PER ANNO - ADOLESCENTI")
ggplot(data = terapiaadolescenti, mapping = aes(x=paziente, y=imp_richiesto))+
  geom_point(mapping = aes(color = num_denti)) #ci sono dei punti da investigare
filter(X20210924_anon_odonto, den_prestazione=="TERAPIA ORTODONTICA CON APPARECCHIATURE FISSE PER ARCATA PER ANNO - ADOLESCENTI", imp_richiesto>3000 )
impianto <- filter(X20210924_anon_odonto, den_prestazione == "IMPIANTO OSTEOINTEGRATO (RICOPERTI IN CERAMICA, CARBON-VITREOUS, IDROSSIAPATITE, TITANIO PURO) PER ELEMENTO - COME UNICA PRESTAZIONE*")
ggplot(data = impianto, mapping = aes(x=paziente, y=imp_richiesto))+
  geom_point(mapping = aes(color = num_denti))









