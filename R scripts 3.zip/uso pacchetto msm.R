library(msm)
cav <- cav
 #raggruppa per uguale PTNUM e mi dice i passaggi tra state
Q1 <- rbind ( c(0, 0.25, 0, 0.25),
                            c(0.166, 0, 0.166, 0.166), #in diagonale metto 0 e negli altri 0,5/num posto della riga in cui non va zero
                            c(0, 0.25, 0, 0.25),       #nella diagonale 0 poich� trova probabilit� tramite le altre due
                            c(0, 0, 0, 0) )
Q.crude1 <- crudeinits.msm(state ~ years, PTNUM, data=cav,   #crea da solo la matrice, se ci sono molti cambiamenti di stato potrebbe non essere un buon valore iniziale
                           qmatrix=Q1)

#risolvere il modello significa trovare i valori q_i,j che massimizzano la likelihood
#quindi se risolvo trovo i valori approssimati di transizione da uno stato all'altro

cav.msm <- msm( state ~ years, subject=PTNUM, data = cav, qmatrix = Q1, deathexact = 4)
#data di morte esatta, prima non so in che stato era
cav.msm #

cavsex.msm <- msm( state ~ years, subject=PTNUM, data = cav,         #considera la dipendenza dal sesso del paziente
                    qmatrix = Q, deathexact = 4, covariates = ~ sex)
qmatrix.msm(cavsex.msm) #matrice q rispetto a questo modello

pmatrix.msm(cav.msm, t=10) #transition probability matrix al decimo anno per Q ritenuta costante

pnext.msm(cav.msm) #probabilit� che lo stato dopo r sia s (r=s --> 0), non specifico l'anno qui

totlos.msm(cav.msm) #stima tempo di permanenza in ogni stato

efpt.msm(cav.msm, tostate = 3) #tempo stimato di arrivo in uno stato partendo da 3, � Inf perch� potrebbe morire prima di arrivarci

envisits.msm(cav.msm) #stima numero atteso di visite per ogni stato

qratio.msm(cav.msm, ind1=c(2,1), ind2=c(1,2)) #stima rapporto tra q_2,1 e q_1,2, quindi guarire (da 2 a 1) � 1.8 pi� probabile che progredire (da 1 a 2)

hazard.msm(cavsex.msm) #effetto covariate su ogni q_i,j, hazard ratio

plot(cav.msm, legend.pos=c(8, 1)) #probabilit� di sopravvivenza per ogni stato, ovvero di non entrare nello stato 4


#calcolo tempo di esecuzione
t0=Sys.time()
cav.msm <- msm( state ~ years, subject=PTNUM, data = cav, qmatrix = Q, deathexact = 4)
Sys.time()-t0



x <- tibble::add_row(paz1, paz2)
x <- tibble::add_row(x, paz3)
x <- tibble::add_row(x, paz4)
x <- tibble::add_row(x, paz5)
 x <- tibble::add_row(x, paz6)
 x <- tibble::add_row(x, paz7)
 x <- tibble::add_row(x, paz8)
 x <- tibble::add_row(x, paz9)
 x <- tibble::add_row(x, paz10)
 x <- tibble::add_row(x, paz11)
 x <- tibble::add_row(x, paz12)
 x <- tibble::add_row(x, paz13)
 x <- tibble::add_row(x, paz14)
 x <- tibble::add_row(x, paz15)
 x <- tibble::add_row(x, paz16)
 x <- tibble::add_row(x, paz17)
 x <- tibble::add_row(x, paz18)
 x <- tibble::add_row(x, paz19)
 x <- tibble::add_row(x, paz20)
 num_prestxpazX <- group_by(x, paziente)%>%
                       count()
 y <- group_by(x, den_prestazione)%>%
    count()

